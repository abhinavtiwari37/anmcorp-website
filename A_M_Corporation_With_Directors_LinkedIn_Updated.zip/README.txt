A & M Corporation website — updated with the supplied logo and original skilling activity illustrations.

Upload ALL files in this folder together to your web host, keeping index.html, am-logo.png and the three .svg files in the same folder.

To preview offline, double-click index.html.

Colors: corporate red, navy blue and white based on your supplied logo.

Directors section: Abhinav Tiwari and Prakash Gautam photos and profiles included.
Abhinav biography is a general professional summary, not verified from LinkedIn; replace with approved biography if needed.
